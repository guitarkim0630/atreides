 let r1 = 125; // 첫 번째 진자의 길이
let r2 = 125; // 두 번째 진자의 길이
let m1 = 10;  // 첫 번째 진자의 질량
let m2 = 10;  // 두 번째 진자의 질량
let a1;       // 첫 번째 진자의 초기 각도
let a2;       // 두 번째 진자의 초기 각도
let a1_v = 0; // 첫 번째 진자의 각속도
let a2_v = 0; // 두 번째 진자의 각속도
let g = 1;    // 중력 가속도

function setup() {
  createCanvas(800, 600);
  a1 = Math.PI / 4 + Math.random() * Math.PI / 2; // 초기 각도를 랜덤하게 설정 (45도에서 135도 사이)
  a2 = Math.PI / 4 + Math.random() * Math.PI / 2; // 초기 각도를 랜덤하게 설정 (45도에서 135도 사이)
  background(255);
}

function draw() {
  background(255);

  // 각가속도 계산 (이중 진자의 운동 방정식)
  let num1 = -g * (2 * m1 + m2) * sin(a1);
  let num2 = -m2 * g * sin(a1 - 2 * a2);
  let num3 = -2 * sin(a1 - a2) * m2;
  let num4 = a2_v * a2_v * r2 + a1_v * a1_v * r1 * cos(a1 - a2);
  let den = r1 * (2 * m1 + m2 - m2 * cos(2 * a1 - 2 * a2));
  let a1_a = (num1 + num2 + num3 * num4) / den;

  num1 = 2 * sin(a1 - a2);
  num2 = (a1_v * a1_v * r1 * (m1 + m2) + g * (m1 + m2) * cos(a1) + a2_v * a2_v * r2 * m2 * cos(a1 - a2));
  den = r2 * (2 * m1 + m2 - m2 * cos(2 * a1 - 2 * a2));
  let a2_a = (num1 * num2) / den;

  // 각속도와 각도 업데이트
  a1_v += a1_a;
  a2_v += a2_a;
  a1 += a1_v;
  a2 += a2_v;

  // 진자의 위치 계산
  let x1 = r1 * sin(a1);
  let y1 = r1 * cos(a1);
  let x2 = x1 + r2 * sin(a2);
  let y2 = y1 + r2 * cos(a2);

  // 진자 그리기
  stroke(0);
  line(width / 2, height / 2, width / 2 + x1, height / 2 + y1);
  fill(127);
  ellipse(width / 2 + x1, height / 2 + y1, m1, m1);
  line(width / 2 + x1, height / 2 + y1, width / 2 + x2, height / 2 + y2);
  fill(127);
  ellipse(width / 2 + x2, height / 2 + y2, m2, m2);
}
